// Simplified recognition wrapper for v0_bundle
import * as faceapi from 'face-api.js';

export type KnownFace = { id: number; name: string; descriptor: Float32Array };

export async function findBestMatch(descriptor: Float32Array, known: KnownFace[], threshold = 0.6) {
  let best: { match: KnownFace | null; distance: number } = { match: null, distance: Infinity };
  for (const k of known) {
    // Euclidean distance
    let sum = 0;
    for (let i = 0; i < descriptor.length; i++) {
      const d = descriptor[i] - k.descriptor[i];
      sum += d * d;
    }
    const dist = Math.sqrt(sum);
    if (dist < best.distance) {
      best = { match: k, distance: dist };
    }
  }
  // Map distance to confidence-like score (not exact)
  const confidence = Math.max(0, 1 - best.distance);
  return { ...best, confidence, recognized: best.distance < threshold };
}
