const https = require('https');
const fs = require('fs');
const path = require('path');

const DEST = path.join(__dirname, '..', 'public', 'models');
const BASE = 'https://justadudewhohacks.github.io/face-api.js/models';

const files = [
  'tiny_face_detector_model-weights_manifest.json',
  'tiny_face_detector_model-shard1.bin',
  'face_landmark_68_model-weights_manifest.json',
  'face_landmark_68_model-shard1.bin',
  'face_recognition_model-weights_manifest.json',
  'face_recognition_model-shard1.bin'
];

if (!fs.existsSync(DEST)) fs.mkdirSync(DEST, { recursive: true });

async function download(file) {
  const url = `${BASE}/${file}`;
  const destPath = path.join(DEST, file);
  return new Promise((resolve, reject) => {
    const fileStream = fs.createWriteStream(destPath);
    https.get(url, (res) => {
      if (res.statusCode !== 200) return reject(new Error(`Failed to download ${file}: ${res.statusCode}`));
      res.pipe(fileStream);
      fileStream.on('finish', () => fileStream.close(resolve));
    }).on('error', reject);
  });
}

(async () => {
  try {
    for (const f of files) {
      console.log('Downloading', f);
      await download(f);
    }
    console.log('✅ Models downloaded to', DEST);
  } catch (err) {
    console.error('Download failed', err);
    process.exit(1);
  }
})();
