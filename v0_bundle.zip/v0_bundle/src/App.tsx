import React, { useState } from 'react';
import RealtimeCamera from './components/RealtimeCamera';

export default function App() {
  const [enrolled, setEnrolled] = useState(false);

  const handleMultiCapture = async (images: string[]) => {
    console.log('Captured images:', images.length);
    // In real app average embeddings; here just mark enrolled
    setEnrolled(true);
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>v0 Bundle - Facial Recognition</h1>
      <RealtimeCamera onMultiCapture={handleMultiCapture} burstCount={5} />
      <div style={{ marginTop: 12 }}>{enrolled ? 'Enrolled' : 'Not enrolled'}</div>
    </div>
  );
}
