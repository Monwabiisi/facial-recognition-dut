// Copied detection engine (v0 bundle)
import * as faceapi from 'face-api.js';
import Human from '@vladmandic/human';
import { FaceDetection } from '@mediapipe/face_detection';

export type Engine = 'faceapi' | 'human' | 'mediapipe';

export async function initEngine(engine: Engine, human?: any, onProgress?: (s:string)=>void) {
  if (engine === 'faceapi') {
    const url = 'https://justadudewhohacks.github.io/face-api.js/models';
    await faceapi.nets.tinyFaceDetector.loadFromUri(url);
    await faceapi.nets.faceLandmark68Net.loadFromUri(url);
    await faceapi.nets.faceRecognitionNet.loadFromUri(url);
  }
  if (engine === 'human' && human) {
    await human.load();
  }
}

export async function detectOnce(engine: Engine, input: HTMLVideoElement | HTMLImageElement, human?: any) {
  if (engine === 'mediapipe') {
    const fd = new FaceDetection({ locateFile: (f:string)=>`https://cdn.jsdelivr.net/npm/@mediapipe/face_detection/${f}` });
    fd.setOptions({ model: 'short', minDetectionConfidence: 0.5 });
    return new Promise<any[]>((resolve)=>{
      fd.onResults((res:any)=>{
        const videoEl = input as HTMLVideoElement;
        const vidW = videoEl.videoWidth || (input as HTMLImageElement).width || 0;
        const vidH = videoEl.videoHeight || (input as HTMLImageElement).height || 0;
        const out = (res.detections||[]).map((d:any)=>({ x: d.boundingBox.xCenter*vidW - (d.boundingBox.width*vidW)/2, y: d.boundingBox.yCenter*vidH - (d.boundingBox.height*vidH)/2, width: d.boundingBox.width*vidW, height: d.boundingBox.height*vidH }));
        resolve(out);
      });
      fd.send({ image: input });
    });
  }

  if (engine === 'human' && human) {
    const res = await human.detect(input as HTMLVideoElement);
    const faces = res.face || [];
    return faces.map((f:any)=>({ x: f.box[0], y: f.box[1], width: f.box[2], height: f.box[3] }));
  }

  const results = await faceapi.detectAllFaces(input as HTMLVideoElement, new faceapi.TinyFaceDetectorOptions({ inputSize: 256, scoreThreshold: 0.5 })).withFaceLandmarks().withFaceDescriptors();
  return results.map((r:any)=>({ x: r.detection.box.x, y: r.detection.box.y, width: r.detection.box.width, height: r.detection.box.height, embedding: r.descriptor }));
}
