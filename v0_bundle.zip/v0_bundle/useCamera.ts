// Copied useCamera (v0 bundle)
import { useCallback, useEffect, useRef, useState } from "react";

type Facing = "user" | "environment";

export function useCamera() {
  const videoRef = useRef<HTMLVideoElement | null>(null);

  const [ready, setReady] = useState(false);
  const [facing, setFacing] = useState<Facing>("user");
  const [error, setError] = useState<string | null>(null);

  const streamRef = useRef<MediaStream | null>(null);

  const stopStream = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    const v = videoRef.current;
    if (v) v.srcObject = null;
  }, []);

  const startStream = useCallback(async (which: Facing) => {
    setError(null);
    setReady(false);
    stopStream();
    try {
      const v = videoRef.current;
      if (!v) throw new Error("Video element not mounted yet.");
      v.muted = true;
      v.setAttribute("muted", "");
      v.playsInline = true;
      v.setAttribute("playsinline", "");

      const constraints: MediaStreamConstraints = {
        audio: false,
        video: { facingMode: { ideal: which }, width: { ideal: 1280 }, height: { ideal: 720 } },
      };

      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      streamRef.current = stream;
      v.srcObject = stream;

      await new Promise<void>((resolve) => {
        if (v.readyState >= 1) return resolve();
        const onMeta = () => {
          v.removeEventListener("loadedmetadata", onMeta);
          resolve();
        };
        v.addEventListener("loadedmetadata", onMeta, { once: true });
      });

      try {
        await v.play();
      } catch {
        await new Promise((r) => setTimeout(r, 50));
        await v.play();
      }

      setReady(true);
    } catch (e: any) {
      console.debug('useCamera startStream error object:', e);
      setError(e?.message || String(e));
      stopStream();
    }
  }, [stopStream]);

  useEffect(() => {
    startStream(facing);
    return () => stopStream();
  }, []);

  const flipCamera = useCallback(async () => {
    const next = facing === "user" ? "environment" : "user";
    setFacing(next);
    await startStream(next);
  }, [facing, startStream]);

  useEffect(() => {
    const handler = async () => {
      if (document.hidden) return;
      const v = videoRef.current;
      if (v && v.srcObject && v.paused) {
        try { await v.play(); } catch {}
      }
    };
    document.addEventListener("visibilitychange", handler);
    return () => document.removeEventListener("visibilitychange", handler);
  }, []);

  return { videoRef, ready, facing, flipCamera, error };
}
