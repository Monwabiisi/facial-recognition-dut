// Copied recognition engine (v0 bundle)
import * as faceapi from 'face-api.js';

function euclidean(a: Float32Array, b: Float32Array) {
  let sum = 0;
  for (let i = 0; i < a.length; i++) {
    const d = a[i] - b[i];
    sum += d*d;
  }
  return Math.sqrt(sum);
}

export function recognize(bestDescriptor: Float32Array, store: Array<{label:string, descriptors:number[][]}>, threshold = 0.6) {
  if (!store.length) return { label: 'unknown', distance: 1, confidence: 0 };
  let bestLabel = 'unknown';
  let bestDist = 1;
  let confidence = 0;
  for (const entry of store) {
    const distances = entry.descriptors.map(d => euclidean(bestDescriptor, new Float32Array(d)));
    distances.sort((a,b)=>a-b);
    const topN = Math.max(1, Math.min(3, Math.floor(distances.length/2)));
    const avgDist = distances.slice(0, topN).reduce((a,b)=>a+b,0)/topN;
    if (avgDist < bestDist) { bestDist = avgDist; bestLabel = entry.label; confidence = Math.max(0, Math.min(1, 1 - (bestDist/threshold))); }
  }
  if (bestDist > threshold) return { label: 'unknown', distance: bestDist, confidence: 0 };
  return { label: bestLabel, distance: bestDist, confidence };
}
