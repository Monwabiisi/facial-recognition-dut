# v0_bundle - Facial Recognition Snapshot

This folder contains a runnable snapshot (v0) of the facial recognition backend + minimal frontend engine for prototyping.

Quick start (Windows PowerShell):

1. Install dependencies:

```powershell
cd v0_bundle
npm install
```

2. Download face-api models (into `v0_bundle/public/models`):

```powershell
npm run get-models
```

3. Start backend only:

```powershell
npm run server
```

4. Start frontend (in a separate terminal):

```powershell
npm run frontend
```

Notes:
- This bundle includes a copy of the Express server and simplified engine wrappers.
- If you want a single `npm run dev` to run both server and frontend, use `npm run dev` (requires `concurrently`).
